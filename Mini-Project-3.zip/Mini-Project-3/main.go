package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"sekolahbeta/hacker/config"
	"sekolahbeta/hacker/fitur"
	"sekolahbeta/hacker/model"
	"strings"
	"time"

	"github.com/joho/godotenv"
	"github.com/jung-kurt/gofpdf"
	"github.com/sirupsen/logrus"
)

var ListBuku []model.Book

func InitEnv() {
	err := godotenv.Load(".env")
	if err != nil {
		logrus.Warn("Cannot load env file, using system env")
	}

}

func main() {
	InitEnv()
	config.OpenDB()

	os.Mkdir("pdf", 0777)

	var sistemMenu int
	fmt.Println("+=============================================+")
	fmt.Println("| Aplikasi Manajemen Daftar Buku Perpustakaan |")
	fmt.Println("+=============================================+")
	fmt.Println("| Silahkan Pilih Menu : ")
	fmt.Println("| 1. Tambah Buku Baru")
	fmt.Println("| 2. Lihat Buku")
	fmt.Println("| 3. Hapus Buku")
	fmt.Println("| 4. Edit Buku")
	fmt.Println("| 5. Print Buku")
	fmt.Println("| 6. Import Buku")
	fmt.Println("| 9. Keluar")
	fmt.Println("+=============================================+")
	fmt.Print("| Masukkan Pilihanmu : ")
	_, err := fmt.Scanln(&sistemMenu)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
	}

	switch sistemMenu {
	case 1:
		InputBukuBaru()
	case 2:
		fmt.Println("+=============================================+")
		fmt.Println("+=============================================+")
		fmt.Println("| =+=+=+=+=+=      List Buku      =+=+=+=+=+= |")
		fmt.Println("+=============================================+")
		fitur.Books()
	case 3:
		HapusBukuByID(&model.Model{})
	case 4:
		EditBuku(&model.Book{})
	case 5:
		PrintBuku()
	case 6:
		CsvImport()
	case 9:
		os.Exit(0)

	}

	main()

}

func CsvImport() {
	userInput := bufio.NewReader(os.Stdin)
	db := config.OpenDB()
	// err := config.OpenDB()
	// if err != nil {
	// 	log.Fatal("Terjadi Error 1 : ", err)
	// }

	fmt.Print("| Masukkan Path/Lokasi File : ")
	filePath, _ := userInput.ReadString('\n')
	filePath = strings.TrimSpace(filePath)
	if err := fitur.ImportCSV(db, filePath); err != nil {
		log.Fatal("Terjadi Error : ", err)
	}

	fmt.Println("Data berhasil diimport!")
}

func InputBukuBaru() {
	userInput := bufio.NewReader(os.Stdin)

	isbnTambahan := ""
	judulBukuTambahan := ""
	penulisBukuTambahan := ""
	tahunTerbitBukuTambahan := 0
	stokBukuTambahan := 0
	gambarBukuTambahan := ""

	//Kode Buku Tambahan
	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=+=+=+=   Tambah Buku Baru  =+=+=+=+=+= |")
	fmt.Println("+=============================================+")
	fmt.Print("| Silahkan Input ISBN Buku : ")
	isbnTambahan, _ = userInput.ReadString('\n')
	isbnTambahan = strings.TrimSpace(isbnTambahan)

	for _, buku := range ListBuku {
		if buku.ISBN == isbnTambahan {
			fmt.Println("+=============================================+")
			fmt.Println("+=============================================+")
			fmt.Println("| =+=+=+=+ Maaf ISBN Buku Sudah Ada! +=+=+=+= |")
			fmt.Println("+=============================================+")
			return
		}
	}

	//Judul Buku Tambahan
	fmt.Print("| Silahkan Input Judul Buku : ")
	judulBukuTambahan, _ = userInput.ReadString('\n')
	judulBukuTambahan = strings.TrimSpace(judulBukuTambahan)

	//Pengarang Buku Tambahan
	fmt.Print("| Silahkan Input Penulis Buku : ")
	penulisBukuTambahan, _ = userInput.ReadString('\n')
	penulisBukuTambahan = strings.TrimSpace(penulisBukuTambahan)

	//Tahun Terbit Buku Tambahan
	fmt.Print("| Silahkan Input Tahun Terbit Buku : ")
	_, err := fmt.Scanln(&stokBukuTambahan)
	if err != nil {
		fmt.Println("Terjadi Error:", err)
		return
	}

	//Stok Buku Tambahan
	fmt.Print("| Silahkan Input Stok Buku : ")
	_, err = fmt.Scanln(&stokBukuTambahan)
	if err != nil {
		fmt.Println("Terjadi Error:", err)
		return
	}

	//Tahun Terbit Buku Tambahan
	fmt.Print("| Silahkan Input Link Gambar Buku : ")
	gambarBukuTambahan, _ = userInput.ReadString('\n')
	gambarBukuTambahan = strings.TrimSpace(gambarBukuTambahan)

	booksData := model.Book{
		Judul:   judulBukuTambahan,
		ISBN:    isbnTambahan,
		Penulis: penulisBukuTambahan,
		Tahun:   uint(tahunTerbitBukuTambahan),
		Stok:    uint(stokBukuTambahan),
		Gambar:  gambarBukuTambahan,
	}

	err = booksData.Create(config.Mysql.DB)
	if err != nil {
		fmt.Println("Terjadi Error")
	}
	fmt.Println("| Berikut adalah ID Buku : ", booksData.ID)

	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=+=    Buku Berhasil Terinput   =+=+=+= |")
	fmt.Println("+=============================================+")
	var inputBaru string
	fmt.Print("| Apakah Anda ingin menambah buku lagi? (y/n)?: ")
	_, err = fmt.Scanln(&inputBaru)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	if strings.ToLower(inputBaru) == "y" {
		InputBukuBaru()
	} else {
		main()
	}

}

func HapusBukuByID(bk *model.Model) {
	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=+=+=+=      Hapus Buku     =+=+=+=+=+= |")
	fmt.Println("+=============================================+")
	fitur.Books()
	fmt.Println("+=============================================+")
	var kodeHapusBuku uint
	fmt.Print("| Masukkan ID Buku yang akan dihapus: ")
	_, err := fmt.Scanln(&kodeHapusBuku)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	booksData := model.Book{
		Model: model.Model{
			ID: kodeHapusBuku,
		},
	}

	err = booksData.DeleteByID(config.Mysql.DB)
	if err != nil {
		fmt.Println("Terjadi Error : ", err.Error())
	}

}

func EditBuku(buku *model.Book) {
	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=+=+=+=+=    Edit Buku    =+=+=+=+=+=+= |")
	fmt.Println("+=============================================+")
	fitur.Books()
	fmt.Println("+=============================================+")
	var kodeEditBuku uint
	fmt.Print("| Masukkan ID Buku yang akan diedit: ")
	_, err := fmt.Scanln(&kodeEditBuku)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=+=   Masukkan Informasi Baru   =+=+=+= |")
	fmt.Println("+=============================================+")

	userInput := bufio.NewReader(os.Stdin)

	//Judul Buku Tambahan
	fmt.Print("| Silahkan Input Judul Buku : ")
	judulBukuTambahan, err := userInput.ReadString('\n')
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	judulBukuTambahan = strings.Replace(judulBukuTambahan, "\n", "", 1)

	//Pengarang Buku Tambahan
	fmt.Print("| Silahkan Input ISBN Buku : ")
	_, err = fmt.Scanln(&buku.ISBN)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	//Penerbit Buku Tambahan
	fmt.Print("| Silahkan Input Penulis Buku : ")
	penulisBukuTambahan, err := userInput.ReadString('\n')
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	penulisBukuTambahan = strings.Replace(penulisBukuTambahan, "\n", "", 1)

	//Jumlah Halaman Buku Tambahan
	fmt.Print("| Silahkan Input Tahun Terbit Buku : ")
	_, err = fmt.Scanln(&buku.Tahun)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	//Tahun Terbit Buku Tambahan
	fmt.Print("| Silahkan Input Stok Buku : ")
	_, err = fmt.Scanln(&buku.Stok)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	//Penerbit Buku Tambahan
	fmt.Print("| Silahkan Input Link Gambar Buku : ")
	gambarBukuTambahan, err := userInput.ReadString('\n')
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	gambarBukuTambahan = strings.Replace(gambarBukuTambahan, "\n", "", 1)

	booksData := model.Book{
		ISBN:    buku.ISBN,
		Penulis: penulisBukuTambahan,
		Tahun:   buku.Tahun,
		Judul:   judulBukuTambahan,
		Gambar:  gambarBukuTambahan,
		Stok:    buku.Stok,
		Model: model.Model{
			ID: kodeEditBuku,
		},
	}

	booksErr := booksData.UpdateOneByID(config.Mysql.DB)
	if booksErr != nil {
		fmt.Println("Terjadi Error : ", booksErr.Error())
	}

	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=+=+=  Buku Berhasil Diubah!  =+=+=+=+= |")
	fmt.Println("+=============================================+")

}

func PrintBuku() {
	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=+=+=+=     Print Buku     =+=+=+=+=+= |")
	fmt.Println("+=============================================+")
	fitur.Books()
	fmt.Println("+=============================================+")
	var pilihan string
	fmt.Print("| Apakah Anda ingin print semua buku (y/n)?: ")
	_, err := fmt.Scanln(&pilihan)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	if strings.ToLower(pilihan) == "y" {
		printSemuaBuku()
	} else {
		printBukuTunggal()
	}
}

func printBukuTunggal() {
	var kodePrintBuku int
	fmt.Print("| Masukkan ID Buku yang ingin di-print: ")
	_, err := fmt.Scanln(&kodePrintBuku)
	if err != nil {
		fmt.Println("Telah Terjadi Error : ", err)
		return
	}

	buku := model.Book{
		Model: model.Model{
			ID: uint(kodePrintBuku),
		},
	}

	x, err := buku.GetByID(config.Mysql.DB)
	if err != nil {
		fmt.Println("Terjadi Error : ", err.Error())
	}

	buatPdf([]model.Book{x})
	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=+=   Buku Berhasil Di-Print!   =+=+=+= |")
	fmt.Println("+=============================================+")

}

func printSemuaBuku() {
	buku := model.Book{}

	bk, err := buku.GetAll(config.Mysql.DB)
	if err != nil {
		fmt.Println("Terjadi Error : ", err.Error())
	}
	buatPdf(bk)

	fmt.Println("+=============================================+")
	fmt.Println("+=============================================+")
	fmt.Println("| =+=+=  Semua Buku Berhasil Di-Print!  =+=+= |")
	fmt.Println("+=============================================+")
}

func buatPdf(bukus []model.Book) {
	pdf := gofpdf.New("P", "mm", "A4", "")
	pdf.AddPage()

	pdf.SetFont("Arial", "B", 16)
	pdf.Cell(40, 10, "Informasi Buku")

	for _, buku := range bukus {
		pdf.Ln(10)

		pdf.SetFont("Arial", "", 12)
		pdf.Cell(40, 10, fmt.Sprintf("ISBN : %s", buku.ISBN))
		pdf.Ln(5)
		pdf.Cell(40, 10, fmt.Sprintf("Judul : %s", buku.Judul))
		pdf.Ln(5)
		pdf.Cell(40, 10, fmt.Sprintf("Penulis : %s", buku.Penulis))
		pdf.Ln(5)
		pdf.Cell(40, 10, fmt.Sprintf("Tahun : %d", buku.Tahun))
		pdf.Ln(5)
		pdf.Cell(40, 10, fmt.Sprintf("Gambar : %s", buku.Gambar))
		pdf.Ln(5)
		pdf.Cell(40, 10, fmt.Sprintf("Stok : %d", buku.Stok))
		pdf.Ln(5)
	}

	err := pdf.OutputFileAndClose(fmt.Sprintf("pdf/book-%d.pdf", time.Now().Unix()))
	if err != nil {
		fmt.Println("Terjadi Error :", err)
		return
	}
}
