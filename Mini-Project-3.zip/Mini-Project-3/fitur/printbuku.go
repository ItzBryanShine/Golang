package fitur

import (
	"sekolahbeta/hacker/model"

	"gorm.io/gorm"
)

func GetBookByID(db *gorm.DB, id uint) (model.Book, error) {
	var book model.Book
	if err := db.First(&book, id).Error; err != nil {
		return model.Book{}, err
	}
	return book, nil
}
