package fitur

import (
	"fmt"
	"sekolahbeta/hacker/config"
	"sekolahbeta/hacker/model"

	"gorm.io/gorm"
)

func Books() {
	db := config.OpenDB()

	books := GetAllBooks(db)
	for _, buku := range books {

		fmt.Printf("| Tahun Terbit : %d, ID : %d\n",
			buku.Tahun,
			buku.ID,
		)

		fmt.Printf("| - ISBN Buku : %s\n",
			buku.ISBN,
		)

		fmt.Printf("| - Judul Buku : %s\n",
			buku.Judul,
		)

		fmt.Printf("| - Penulis : %s\n",
			buku.Penulis,
		)

		fmt.Printf("| - Stok : %d\n",
			buku.Stok,
		)

		fmt.Printf("| - Gambar : %s\n",
			buku.Gambar,
		)

		fmt.Println("-----------------------------------------------")
	}

}

func GetAllBooks(db *gorm.DB) []model.Book {
	var books []model.Book
	db.Limit(20).Find(&books)
	return books
}
