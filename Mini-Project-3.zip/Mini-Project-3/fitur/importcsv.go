package fitur

import (
	"encoding/csv"
	"fmt"
	"os"
	"sekolahbeta/hacker/config"
	"sekolahbeta/hacker/model"
	"strconv"

	"gorm.io/gorm"
)

func UpsertBook(db *gorm.DB, book *model.Book) error {
	var bookExist model.Book
	if err := db.
		Where("id = ?", book.ID).
		First(&bookExist).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			booksData := model.Book{
				Judul:   book.Judul,
				ISBN:    book.ISBN,
				Penulis: book.Penulis,
				Tahun:   book.Tahun,
				Stok:    book.Stok,
				Gambar:  book.Gambar,
			}

			err := booksData.Create(config.Mysql.DB)
			if err != nil {
				fmt.Println("Terjadi Error")
			}

		} else {
			return err
		}

	} else {
		if err := db.Model(&bookExist).Updates(book).Error; err != nil {
			return err
		}
	}

	return nil
}

func ImportCSV(db *gorm.DB, filePath string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	csvReader := csv.NewReader(file)
	records, err := csvReader.ReadAll()
	if err != nil {
		return err
	}

	for i, record := range records {
		if i == 0 {
			continue
		}

		idRecord, err := strconv.Atoi(record[0])
		if err != nil {
			idRecord = 0
		}

		stokRecord, err := strconv.Atoi(record[6])
		if err != nil {
			stokRecord = 0
		}

		tahunRecord, err := strconv.Atoi(record[3])
		if err != nil {
			tahunRecord = 0
		}

		book := model.Book{
			ISBN:    record[1],
			Penulis: record[2],
			Tahun:   uint(tahunRecord),
			Judul:   record[4],
			Gambar:  record[5],
			Stok:    uint(stokRecord),
			Model: model.Model{
				ID: uint(idRecord),
			},
		}
		if err := UpsertBook(db, &book); err != nil {
			fmt.Printf("Terjadi Error Pada Saat Upsert Buku : %v", err)
		}
	}

	return nil
}
