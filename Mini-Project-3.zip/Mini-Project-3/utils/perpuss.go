package utils

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"sekolahbeta/hacker/config"
	"sekolahbeta/hacker/model"
	"time"
)

func GetBooksList() ([]model.Book, error) {
	var books model.Book
	return books.GetAll(config.Mysql.DB)
}

func GetBookByID(conn *sql.DB, id uint, ctx context.Context) (model.Book, error) {
	res := model.Book{}
	syn := fmt.Sprintf(`
		SELECT * FROM perpus WHERE id = %d LIMIT 1
	`, id)

	row, err := conn.QueryContext(ctx, syn)
	if err != nil {
		return model.Book{}, err
	}

	defer func() {
		err := row.Close()
		if err != nil {
			log.Fatal(err)
		}
	}()

	for row.Next() {
		err = row.Scan(
			&res.ID,
			&res.Judul,
			&res.ISBN,
			&res.Penulis,
			&res.Tahun,
			&res.Stok,
			&res.Gambar,
		)
		if err != nil {
			return model.Book{}, err
		}
	}

	return res, nil
}

func InsertBookData(data model.Book) error {
	data.CreatedAt = time.Now()
	data.UpdatedAt = time.Now()
	return data.Create(config.Mysql.DB)
}
