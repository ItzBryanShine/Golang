package model_test

import (
	"fmt"
	"sekolahbeta/hacker/config"
	"sekolahbeta/hacker/model"
	"testing"

	"github.com/joho/godotenv"
	"github.com/stretchr/testify/assert"
)

func Init() {
	err := godotenv.Load("../.env")
	if err != nil {
		fmt.Println("env not found, using global env")
	}
	config.OpenDB()

}

func TestCreateBuku(t *testing.T) {
	Init()

	booksData := model.Book{
		Judul:   "Belajar Aja",
		ISBN:    "55",
		Penulis: "Kelas Hacker",
		Tahun:   2032,
		Stok:    56,
		Gambar:  "IG : @markasbali",
	}

	err := booksData.Create(config.Mysql.DB)
	assert.Nil(t, err)

	fmt.Println(booksData.ID)

}

func TestDeleteByID(t *testing.T) {
	Init()

	booksData := model.Book{
		Judul:   "Belajar Aja",
		ISBN:    "55",
		Penulis: "Kelas Hacker",
		Tahun:   2032,
		Stok:    56,
		Gambar:  "IG : @markasbali",
	}

	err := booksData.Create(config.Mysql.DB)
	assert.Nil(t, err)

	err = booksData.DeleteByID(config.Mysql.DB)
	assert.Nil(t, err)
}

func TestGetByID(t *testing.T) {
	Init()

	booksData := model.Book{
		Judul:   "Belajar Aja",
		ISBN:    "55",
		Penulis: "Kelas Hacker",
		Tahun:   2032,
		Stok:    56,
		Gambar:  "IG : @markasbali",
	}

	err := booksData.Create(config.Mysql.DB)
	assert.Nil(t, err)

	data, err := booksData.GetByID(config.Mysql.DB)
	assert.Nil(t, err)

	fmt.Println(data)
}

func TestGetAll(t *testing.T) {
	Init()

	carData := model.Book{
		Judul:   "Belajar C++",
		ISBN:    "1",
		Tahun:   2002,
		Penulis: "Siplesples",
		Stok:    24,
		Gambar:  "sadsdvbc",
	}

	err := carData.Create(config.Mysql.DB)
	assert.Nil(t, err)

	res, err := carData.GetAll(config.Mysql.DB)
	assert.Nil(t, err)
	assert.GreaterOrEqual(t, len(res), 1)

	fmt.Println(res)
}

func TestUpdateByID(t *testing.T) {
	Init()

	booksData := model.Book{
		Judul:   "Belajar Aja",
		ISBN:    "55",
		Penulis: "Kelas Hacker",
		Tahun:   2032,
		Stok:    56,
		Gambar:  "IG : @markasbali",
	}

	err := booksData.Create(config.Mysql.DB)
	assert.Nil(t, err)

	booksData.Judul = "Test Update Aja"

	err = booksData.UpdateOneByID(config.Mysql.DB)
	assert.Nil(t, err)
}
